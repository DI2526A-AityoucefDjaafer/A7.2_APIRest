using System.Collections.ObjectModel;
using System.Threading;
using RestSharp;
using Newtonsoft.Json;
using A7._1_SQLite.Models;

namespace A7._1_SQLite.Services
{
    public class PeticionesApi
    {
        private const string BaseUrl = "https://riconet.es/fp/apirest/";

        public ObservableCollection<Libro> GetLibros()
        {
            var client = new RestClient(BaseUrl);
            var request = new RestRequest("libros", Method.Get);
            RestResponse response = client.Execute(request);
            return JsonConvert.DeserializeObject<ObservableCollection<Libro>>(response.Content) ?? new ObservableCollection<Libro>();
        }

        public Libro GetLibro(int id)
        {
            var client = new RestClient(BaseUrl);
            var request = new RestRequest($"libros/{id}", Method.Get);
            RestResponse response = client.Execute(request);
            return JsonConvert.DeserializeObject<Libro>(response.Content);
        }

        public RestResponse PostLibro(Libro nuevoLibro)
        {
            var client = new RestClient(BaseUrl);
            var request = new RestRequest("libros", Method.Post);
            string data = JsonConvert.SerializeObject(nuevoLibro);
            request.AddParameter("application/json", data, ParameterType.RequestBody);
            var response = client.Execute(request);
            Thread.Sleep(1000);
            return response;
        }

        public RestResponse PutLibro(Libro actualizaLibro)
        {
            var client = new RestClient(BaseUrl);
            var request = new RestRequest("libros", Method.Put);
            string data = JsonConvert.SerializeObject(actualizaLibro);
            request.AddParameter("application/json", data, ParameterType.RequestBody);
            var response = client.Execute(request);
            Thread.Sleep(1000);
            return response;
        }

        public RestResponse DeleteLibro(int id)
        {
            var client = new RestClient(BaseUrl);
            var request = new RestRequest($"libros/{id}", Method.Delete);
            var response = client.Execute(request);
            return response;
        }
    }
}