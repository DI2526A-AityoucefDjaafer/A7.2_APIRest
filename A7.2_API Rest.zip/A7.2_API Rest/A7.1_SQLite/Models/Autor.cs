﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A7._1_SQLite.Models
{
    public partial class Autor : ObservableObject
    {
        [ObservableProperty]
        private int _cod;

        [ObservableProperty]
        private string _nombre;

        public Autor ()
        {
            Cod = 0;
            Nombre=string.Empty;
        }
    }
}
