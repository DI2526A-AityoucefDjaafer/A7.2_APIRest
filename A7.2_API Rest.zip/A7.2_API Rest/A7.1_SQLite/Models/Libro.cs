﻿using CommunityToolkit.Mvvm.ComponentModel;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace A7._1_SQLite.Models
{
    [DataContract]
    public partial class Libro : ObservableObject
    {
        private bool baja;
        [JsonIgnore]
        public bool Baja
        {
            get => baja;
            set => SetProperty(ref baja, value);
        }

        private int id;
        [JsonProperty("id")]
        [DataMember]
        public int Id
        {
            get => id;
            set => SetProperty(ref id, value);
        }

        private string titulo = string.Empty;
        [JsonProperty("titulo")]
        [DataMember]
        public string Titulo
        {
            get => titulo;
            set => SetProperty(ref titulo, value);
        }

        private string autor = string.Empty;
        [JsonProperty("autor")]
        [DataMember]
        public string Autor
        {
            get => autor;
            set => SetProperty(ref autor, value);
        }

        public Libro()
        {
            Baja = false;
            Id = 0;
            Titulo = string.Empty;
            Autor = string.Empty;
        }

        public Libro(int id, string titulo, string autor)
        {
            Id = id;
            Titulo = titulo;
            Autor = autor;
            Baja = false;
        }

        public Libro(string titulo, string autor)
        {
            Id = 0;
            Titulo = titulo;
            Autor = autor;
            Baja = false;
        }
    }
}
