﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using A7._1_SQLite.Models;
using System.Collections.ObjectModel;
using System.Windows;

namespace A7._1_SQLite.Services
{
    public static class DatosRepository
    {
        // Ruta y nombre de la base de datos.
        private const string directorioBBDD = "./BBDD";
        private const string rutaNombreBBDD = $"{directorioBBDD}/biblioteca.db";

        // CREAR la base de datos SQLite con dos tablas y datos de ejemplo.
        public static void CrearBBDD()
        {
            // Crear el directorio "./BBDD" si no existe.
            if (!Directory.Exists(directorioBBDD))
            {
                Directory.CreateDirectory(directorioBBDD);
            }

            // Crear la base de datos solo si no existe.
            if (!File.Exists(rutaNombreBBDD))
            {
                using (var connection = new SqliteConnection($"Data Source={rutaNombreBBDD}"))
                {
                    // Abrir la conexión a la base de datos.
                    connection.Open();

                    // Creamos un objeto "command" para ejecutar comandos SQL.  
                    var command = connection.CreateCommand();

                    // Crear la tabla "libros" si no existe.
                    command.CommandText = @"CREATE TABLE libros (
                                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                                            titulo TEXT NOT NULL,
                                            autor TEXT NOT NULL
                                            )";
                    command.ExecuteNonQuery();

                    // Insertar datos de ejemplo en la tabla "libros".
                    command.CommandText = @"INSERT INTO libros (titulo, autor) VALUES
                                            ('Cien Años de Soledad', 'Gabriel García Márquez'),
                                            ('Don Quijote de la Mancha', 'Miguel de Cervantes'),
                                            ('La Sombra del Viento', 'Carlos Ruiz Zafón')";
                    command.ExecuteNonQuery();

                    // Crear la tabla "autores" si no existe.
                    command.CommandText = @"CREATE TABLE autores (
                                            cod INTEGER PRIMARY KEY AUTOINCREMENT,
                                            nombre TEXT NOT NULL
                                            )";
                    command.ExecuteNonQuery();

                    // Insertar datos de ejemplo en la tabla "autores".
                    command.CommandText = @"INSERT INTO autores (nombre) VALUES
                                            ('Gabriel García Márquez'),
                                            ('Miguel de Cervantes'),
                                            ('Carlos Ruiz Zafón')";
                    command.ExecuteNonQuery();

                    // Cerrar la conexión a la base de datos.
                    connection.Close();
                }
            }
        }

        // OBTENER todos los libros de la base de datos.
        public static ObservableCollection<Libro> ObtenerTodosLosLibros()
        {
            ObservableCollection<Libro> listaLibros = new ObservableCollection<Libro>();

            using (var connection = new SqliteConnection($"Data Source={rutaNombreBBDD}"))
            {
                connection.Open();
                
                var command = connection.CreateCommand();
                
                command.CommandText = "SELECT id, titulo, autor FROM libros";
                
                using (var reader = command.ExecuteReader())
                {
                   if (reader.HasRows) { 
                        while (reader.Read())
                        {
                            var libro = new Libro()
                            {
                              Baja = false,
                              Id = reader.GetInt32(0),
                              Titulo = reader.GetString(1),
                              Autor = reader.GetString(2)
                            };

                            listaLibros.Add(libro);
                        }
                    }
                }
                connection.Close();
            }
            return listaLibros;
        }

        // ACTUALIZAR la base de datos entera a partir de una lista de libros,
        // insertando los nuevos y actualizando los existentes.
        public static ObservableCollection<Libro> ActualizarBBDD(ObservableCollection<Libro> MiLista)
        {
            using (var connection = new SqliteConnection($"Data Source={rutaNombreBBDD}"))
            {
                connection.Open();

                var command = connection.CreateCommand();

                int filasActualizadas = 0; // Contador de filas actualizadas.

                foreach (var libro in MiLista)
                {
                    // Si utilizamos las variable C# debemos tener cuidado con el tipo de comillas.
                    //command.CommandText = $"UPDATE libros SET titulo = '{libro.Titulo}', autor = '{libro.Autor}' WHERE id = {libro.Id}";
                    
                    command.Parameters.Clear(); // Limpiar los parámetros anteriores

                    if (libro.Id != 0)
                    {
                        command.CommandText = @"UPDATE libros SET titulo = @tlista, autor = @alista WHERE id = @idlista";

                        command.Parameters.AddWithValue("@tlista", libro.Titulo);
                        command.Parameters.AddWithValue("@alista", libro.Autor);
                        command.Parameters.AddWithValue("@idlista", libro.Id);
                    }
                    else
                    {
                        command.CommandText = @"INSERT INTO libros (titulo, autor) VALUES (@tlista, @alista)";
                        command.Parameters.AddWithValue("@tlista", libro.Titulo);
                        command.Parameters.AddWithValue("@alista", libro.Autor);
                    }

                    filasActualizadas += command.ExecuteNonQuery(); // Para conocer el número de filas actualizadas
 
                }
                connection.Close();

                MessageBox.Show($"Se han actualizado {filasActualizadas} registro(s) en la BBDD.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);

                return ObtenerTodosLosLibros(); // actualizamos la lista desde la BBDD.
            }
        }

        // ELIMINAR los libros dados de baja de la base de datos.
        public static ObservableCollection<Libro> EliminarLibros(ObservableCollection<Libro> MiLista)
        {
            using (var connection = new SqliteConnection($"Data Source={rutaNombreBBDD}"))
            {
                connection.Open();
                
                var command = connection.CreateCommand();

                int filasEliminadas = 0; // Contador de filas eliminadas.

                foreach (var libro in MiLista)
                {
                    if (libro.Baja)
                    {
                        // Si utilizamos las variable C# debemos tener cuidado con el tipo de comillas.
                        //command.CommandText = $"DELETE FROM libros WHERE id = '{libro.Id}'";

                        command.CommandText = @"DELETE FROM libros WHERE id = @idborrar";
                        
                        command.Parameters.Clear(); // Limpiar los parámetros anteriores
                        command.Parameters.AddWithValue("@idborrar", libro.Id);

                        filasEliminadas += command.ExecuteNonQuery(); // ← número de filas eliminadas

                        // NOTA: No eliminamos de la lista aquí, porque estaríamos modificando la colección mientras la recorremos.
                    }
                }
                connection.Close();

                MessageBox.Show($"Filas eliminadas de la BBDD: {filasEliminadas}", "Información", MessageBoxButton.OK, MessageBoxImage.Information);

                // Ahora eliminamos de la lista en MEMORIA los libros que están dados de baja con Id distinto de 0, ya que los que tienen Id = 0 no están en la BBDD.
                // Para evitar problemas al eliminar mientras recorremos la lista, usamos ToList() para crear una copia temporal.
                foreach (var libro in MiLista.ToList())
                {
                    if (libro.Baja && libro.Id != 0)
                    {
                        MiLista.Remove(libro); // Eliminar de la lista en MEMORIA.
                    }
                }
                
                return MiLista; // Devolvemos la lista actualizada.
                                // Aquí puede ser que haya libros que estan en la LISTA (MEMORIA) pero no en la BBDD porque todavía no se han insertado.
            }
        }
    }
}
