﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using A7._1_SQLite.Services;
using A7._1_SQLite.Models;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace A7._1_SQLite.ViewModels
{
    public partial class MainWindowVM : ObservableObject
    {
        // Propiedad "ListaLibros" generada automáticamente.
        [ObservableProperty]
        private ObservableCollection<Libro> _listaLibros;
        
        public MainWindowVM() 
        {
            // Únicamente crea la base de datos si no existe antes en "./BBDD/biblioteca.db",
            // siendo la ruta de origen donde está el ejecutable de la aplicación.
            // Se crea la BBDD en el servicio "DatosRepository".
            DatosRepository.CrearBBDD();

            ListaLibros = DatosRepository.ObtenerTodosLosLibros();
        }

        // Comando "ActualizarCommand" generado automáticamente.
        [RelayCommand]
        private void Actualizar()
        {
            // Actualiza la BBDD con la lista actual de libros.
            // y actualiza la lista de libros.
            ListaLibros = DatosRepository.ActualizarBBDD(ListaLibros);
        }

        // Comando "EliminarCommand" generado automáticamente.
        [RelayCommand]
        private void Eliminar()
        {
            // Elimina los libros marcados como "Baja" de la BBDD.
            // y actualiza la lista de libros.
            ListaLibros = DatosRepository.EliminarLibros(ListaLibros);
        }
    }
}
